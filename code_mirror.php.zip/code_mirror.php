<?php
use WHMCS\Database\Capsule;

add_hook('AdminAreaHeadOutput', 1, function($vars) {
    return '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/cobalt.min.css">';
});

add_hook('AdminAreaFooterOutput', 1, function($vars) {
    return '<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/htmlmixed/htmlmixed.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/edit/closetag.js"></script>
            <script>
            document.addEventListener("DOMContentLoaded", function () {
                var textareas = document.querySelectorAll("textarea[name^=\'sections\'][name$=\'[custom_code]\']");
                textareas.forEach(function(textarea) {
                    var editor = CodeMirror.fromTextArea(textarea, {
                        mode: "htmlmixed",
                        theme: "cobalt",
                        lineNumbers: true,
                        autoCloseTags: true,
                        extraKeys: {
                            "Enter": function(cm) {
                                cm.replaceSelection("\n");
                            }
                        }
                    });
                    // Forzar un refresco del editor después de la inicialización
                    setTimeout(function() {
                        editor.refresh();
                    }, 100);

                    // Eliminar la clase CodeMirror-focused cada vez que se agregue
                    editor.on("focus", function() {
                        editor.getWrapperElement().classList.remove("CodeMirror-focused");
                    });

                    // Eliminar la clase CodeMirror-focused cada vez que se quite el foco
                    editor.on("blur", function() {
                        editor.getWrapperElement().classList.remove("CodeMirror-focused");
                    });
                });
            });
            </script>';
});
?>